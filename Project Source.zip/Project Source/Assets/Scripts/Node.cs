using System.Collections.Generic;
using UnityEngine;

public enum NodeState
{
    Empty, Open, Close, Start, Target
}

public class Node 
{
    public bool IsWalkable { get; private set; } = true;
    public Vector2Int Key { get; set; }
    public float Weight
    {
        get => weight;
        set
        {
            if (IsWalkable)
            {
                weight = value;
                ColorHelper.SetWeight(value);
            }
        }
    }
    float weight;
    public NodeState State
    {
        get => nodeState;
        set
        {
            nodeState = value;
            ColorHelper.Fade(value);
        }
    }
    NodeState nodeState = NodeState.Empty;
    public Tile Tile { get; }

    TileColorHelper ColorHelper { get; }

    public Node(Tile tile, TileColorHelper colorHelper, List<TileHelper> tileHelpers)
    {
        Tile = tile;
        ColorHelper = colorHelper;

        void FadeGrow(bool isGrow) => IsWalkable = !isGrow;
        void Init() => IsWalkable = true;
        tileHelpers.Add(new TileHelper(FadeGrow, null, Init));
    }

    public void ResetOpenClose()
    {
        if (State == NodeState.Start || State == NodeState.Target)
            return;
        
        if (IsWalkable)
        {
            State = NodeState.Empty;
        }
        else
        {
            nodeState = NodeState.Empty;
            ColorHelper.Reset();
        }
    }
}