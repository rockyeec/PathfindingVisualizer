using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Random = UnityEngine.Random;

public static class Extensions
{
    public static Vector3 With(this Vector3 v, float? x = null, float? y = null, float? z = null)
        => new Vector3(x ?? v.x, y ?? v.y, z ?? v.z);
    public static bool IsLongerThan(this Vector3 v, float length)
        => v.sqrMagnitude > length * length;
    public static bool IsShorterThan(this Vector3 v, float length)
        => v.sqrMagnitude < length * length;
    public static bool IsLongerThan(this Vector2 v, float length)
        => v.sqrMagnitude > length * length;
    public static bool IsShorterThan(this Vector2 v, float length)
        => v.sqrMagnitude < length * length;

    public static Vector3 AsVector3WithYZswap(this Vector2 v2)
        => new Vector3(v2.x, 0.0f, v2.y);
    public static Vector2 AsVector2WithYZswap(this Vector3 v3)
        => new Vector2(v3.x, v3.z);

    public static Vector3 GetNormalPoint(this Vector3 p, Vector3 a, Vector3 b)
    {
        Vector3 ap = p - a;
        Vector3 ab = b - a;
        ab = ab.normalized;        
        Vector3 scalarProjection = Vector3.Dot(ap, ab) * ab;
        return a + scalarProjection;
    }

    public static bool IsInsideLineSegment(this Vector3 p, Vector3 a, Vector3 b)
    {
        float ab = Vector3.Distance(a, b);
        float ap = Vector3.Distance(a, p);
        float pb = Vector3.Distance(p, b);
        return ab == ap + pb;
    }

    public static Collider GetNearest(this List<Collider> colliders, Vector3 position)
        => colliders.OrderBy(c => (position - c.transform.position).sqrMagnitude).FirstOrDefault();

    public static T GetRandom<T>(this List<T> thisList)
        => thisList[Random.Range(0, thisList.Count)];    
    public static T GetRandom<T>(this T[] thisList)
        => thisList[Random.Range(0, thisList.Length)];
    public static T GetRandomKey<T, U>(this Dictionary<T, U> thisDict)
        => thisDict.ToArray().GetRandom().Key;
    public static T GetRandomValue<U, T>(this Dictionary<U, T> thisDict)
        => thisDict.ToArray().GetRandom().Value;

    public static float SmootherStep(this float t)
        => t * t * t * (t * (6.0f * t - 15.0f) + 10.0f);

    public static void Increment(this ref int i, int max)
        => i = (i + 1) % max;
    public static void Decrement(this ref int i, int max)
    {
        --i;
        if (i < 0) i = max - 1;
    }
}
