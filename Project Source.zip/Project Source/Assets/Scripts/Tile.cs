using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(MeshRenderer))]
[RequireComponent(typeof(BoxCollider))]
public class Tile : Poolable, ICanClickDown, ICanClickHold
{
    [Tooltip("Doesn't update during runtime")]
    [SerializeField] float animationDuration = 0.69f;
    [SerializeField] float minimumHeight = 1e-3f;
    [SerializeField] float maximumHeight = 2.0f;
    [SerializeField] TileColorScheme colorScheme = null;

    public Node Node { get; private set; }

    static readonly List<Tile> allTiles = new List<Tile>();

    readonly List<TileHelper> tileHelpers = new List<TileHelper>();
    static bool isGlobalGrow;
    bool isGrow;
    bool isMouseDrag;

    public static void ClearWalls()
    {
        foreach (var item in allTiles)
        {
            item.Node.ResetOpenClose();
            isGlobalGrow = false;
            item.Toggle();
        }
    }

    public void OnClickHeld()
    {
        if (UI_WeightPainter.IsWeightPainting)
        {
            if (DraggableAgent.IsDrag)
                return;

            if (Node.State == NodeState.Start)
                return;

            if (Node.State == NodeState.Target)
                return;

            Node.Weight = UI_WeightPainter.Weight;
        }
        else
        {
            if (DraggableAgent.IsDrag)
                return;

            if (isMouseDrag)
            {
                isMouseDrag = false;
                Toggle();
            }
        }
    }

    public void OnClickDown()
    {
        isMouseDrag = true;
        isGlobalGrow = !isGrow;
    }

    void Toggle()
    {
        bool shouldToggle = isGrow != isGlobalGrow;
        if (!shouldToggle)
            return;

        if (Node.State == NodeState.Start)
            return;

        if (Node.State == NodeState.Target)
            return;

        isGrow = isGlobalGrow;
        foreach (var item in tileHelpers)
        {
            item.FadeGrow?.Invoke(isGrow);
        }
    }

    void Awake()
    {
        var material = GetComponent<MeshRenderer>().material;
        var boxCollider = GetComponent<BoxCollider>();

        var heightHelper = new TileHeightHelper(animationDuration, material, boxCollider, () => minimumHeight, () => maximumHeight, tileHelpers);
        var colorHelper = new TileColorHelper(animationDuration, material, colorScheme, b => enabled = b, tileHelpers);
        Node = new Node(this, colorHelper, tileHelpers);
    }

    void Clicker_OnClickUpGlobal()
        => isMouseDrag = false;

    void Clicker_OnClickDownGlobal()
        => isMouseDrag = true;


    void Update()
    {
        foreach (var item in tileHelpers)
        {
            item.Tick?.Invoke();
        }
    }

    public override void Init()
    {
        base.Init();

        allTiles.Add(this);

        foreach (var item in tileHelpers)
        {
            item.Init?.Invoke();
        }

        Clicker.OnClickDownGlobal += Clicker_OnClickDownGlobal;
        Clicker.OnClickUpGlobal += Clicker_OnClickUpGlobal;
    }

    public override void DeInit()
    {
        base.DeInit();

        allTiles.Remove(this);

        Clicker.OnClickDownGlobal -= Clicker_OnClickDownGlobal;
        Clicker.OnClickUpGlobal -= Clicker_OnClickUpGlobal;
    }
}