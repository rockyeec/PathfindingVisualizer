using UnityEngine;

public class TileOccupier : MonoBehaviour
{
    [SerializeField] NodeState role = NodeState.Start;
    public Tile OccupiedTile { get; private set; } = null;
    NodeState previousTileState = NodeState.Empty;

    public void SetPreviousTileStateEmpty()
    {
        previousTileState = NodeState.Empty;
    }

    public void ClearOccupation()
    {
        OccupiedTile.Node.State = previousTileState;
        OccupiedTile = null;
    }

    public void OccupyTile(Tile tile)
    {
        if (OccupiedTile == tile)
            return;

        if (!tile.Node.IsWalkable)
            return;

        if (OccupiedTile != null)
            OccupiedTile.Node.State = previousTileState;

        OccupiedTile = tile;
        previousTileState = tile.Node.State;

        tile.Node.State = role;
    }
}
