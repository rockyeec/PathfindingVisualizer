using UnityEngine;
using System;
using System.Collections.Generic;

public class TileColorHelper
{
    Material Material { get; }
    Action<bool> EnableAction { get; }
    TileColorScheme ColorScheme { get; }
    Lerper<Color> Lerper { get; }
    Color Color
    {
        get => Material.GetColor(UniformIDs.Color);
        set => Material.SetColor(UniformIDs.Color, value);
    }

    Color weightedColor;
    Color downColor;

    public TileColorHelper(float animationDuration, Material material, TileColorScheme colorScheme, Action<bool> enableAction, List<TileHelper> tileHelpers)
    {
        Material = material;
        EnableAction = enableAction;
        ColorScheme = colorScheme;
        Color = downColor = weightedColor = colorScheme.EmptyColor;
        Lerper = new Lerper<Color>(
            () => Color,
            (a, b, t) => Color = Color.LerpUnclamped(a, b, t))
        { Duration = animationDuration };

        void FadeGrow(bool isGrow)
        {
            EnableAction(true);
            Lerper.Begin(isGrow ? ColorScheme.UpColor : weightedColor);
        }
        void Tick()
        {
            if (!Lerper.TryUpdate())
            {
                EnableAction(false);
            }
        }
        void Init() => Color = downColor = ColorScheme.EmptyColor;

        tileHelpers.Add(new TileHelper(FadeGrow, Tick, Init));
    }

    public void SetWeight(float value)
    {
        weightedColor = Color.LerpUnclamped(ColorScheme.EmptyColor, ColorScheme.UpColor, value);
        Color = weightedColor;
    }

    public void Fade(NodeState state)
    {
        Color color = downColor;

        switch (state)
        {
            case NodeState.Empty:
                color = weightedColor;
                break;

            case NodeState.Open:
                color = ColorScheme.OpenColor;
                break;

            case NodeState.Close:
                color = ColorScheme.CloseColor;
                break;

            case NodeState.Start:
                color = ColorScheme.StartColor;
                break;

            case NodeState.Target:
                color = ColorScheme.TargetColor;
                break;
        }


        EnableAction(true);
        Color previousColor = downColor;
        downColor = color;
        Lerper.Begin(previousColor, downColor);
    }

    public void Reset() => downColor = ColorScheme.EmptyColor;
}
