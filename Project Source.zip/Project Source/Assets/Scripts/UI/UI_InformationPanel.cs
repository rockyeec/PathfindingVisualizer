using UnityEngine;
using TMPro;

public class UI_InformationPanel : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI text = null;

    private void Awake()
    {
        PathUtil.OnComplete += PathUtil_OnComplete;
    }

    private void OnDestroy()
    {
        PathUtil.OnComplete -= PathUtil_OnComplete;
    }

    private void PathUtil_OnComplete(float length, float time, float iterations)
    {
        text.text
            = $"length: {length:n2}\n"
            + $"time: {time:n4}s\n"
            + $"operations: {iterations}";
    }
}
