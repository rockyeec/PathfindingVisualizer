using UnityEngine;

public class UI_WeightPainter : MonoBehaviour
{
    public static bool IsWeightPainting { get; private set; } = false;
    public static float Weight { get; private set; } = 0.0f;

    public void ChangeWeight(string value)
    {
        float.TryParse(value, out float weight);
        Weight = weight;
    }
    public void ChangeWeight(float value) => Weight = value;
    public void SetWeightPaint() => IsWeightPainting = true;
    public void SetObstaclePaint() => IsWeightPainting = false;
}
