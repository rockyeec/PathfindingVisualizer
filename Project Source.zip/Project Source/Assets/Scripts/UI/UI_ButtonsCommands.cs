using UnityEngine;
using UnityEngine.Events;

public class UI_ButtonsCommands : MonoBehaviour
{
    [SerializeField] UnityEvent OnPathfindComplete = null;

    public void StartSearch()
        => PathFindAnimator.FindPath(TileGrid.Seeker, TileGrid.Target);

    public void PauseSearch()
        => PathFindAnimator.Pause();

    public void ClearPath()
        => CancelSearch();

    public void ClearWalls()
    {
        CancelSearch();
        Tile.ClearWalls();
    }

    public void ResumeSearch()
        => PathFindAnimator.Play();

    public void CancelSearch()
    {
        DraggableAgent.SetPreviousTileEmpty();
        PathVisualizer.ResetLine();
        PathUtil.Clear();
    }

    public void Quit()
        => Application.Quit();


    private void Awake()
        => PathUtil.OnComplete += PathUtil_OnComplete;

    private void OnDestroy()
        => PathUtil.OnComplete += PathUtil_OnComplete;

    private void PathUtil_OnComplete(float length, float time, float iterations)
        => OnPathfindComplete?.Invoke();

}
