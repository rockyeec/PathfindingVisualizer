using UnityEngine;
using TMPro;
using System.Collections.Generic;
using System;

[RequireComponent(typeof(TMP_Dropdown))]
public class UI_HeuristicSelector : MonoBehaviour
{
    TMP_Dropdown dropdown;

    readonly List<Heuristic> allHeuristics = new List<Heuristic>();
    readonly List<string> allOptions = new List<string>();

    private void Awake()
    {
        dropdown = GetComponent<TMP_Dropdown>();

        var allHeuristicTypes = SubclassUtil.GetAllSubclasses<Heuristic>();
        foreach (var item in allHeuristicTypes)
        {
            var instance = Activator.CreateInstance(item) as Heuristic;
            allHeuristics.Add(instance);
            allOptions.Add(instance.DisplayName);
        }

        dropdown.ClearOptions();
        dropdown.AddOptions(allOptions);
        dropdown.onValueChanged.AddListener(OnDropdownValueChange);
        dropdown.value = 0;

        OnDropdownValueChange(0);
    }

    void OnDropdownValueChange(int index)
        => PathUtil.Heuristic = allHeuristics[index];
}
