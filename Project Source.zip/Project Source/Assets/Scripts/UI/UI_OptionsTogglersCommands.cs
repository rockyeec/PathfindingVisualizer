using UnityEngine;

public class UI_OptionsTogglersCommands : MonoBehaviour
{
    public void ToggleCantCrossCorners(bool value)
        => NodeNeighbourUtil.IsCrossCorners = !value;

    public void ToggleAllowDiagonal(bool value)
        => NodeNeighbourUtil.IsAllowDiagonal = value;

    public void ToggleBidirectional(bool value)
        => PathUtil.IsBidirectional = value;

    public void ToggleFollowPath(bool value)
        => PathFollower.Enabled = value;
}
