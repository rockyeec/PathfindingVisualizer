using UnityEngine;

public interface IClickable { }
public interface ICanClickDown : IClickable { void OnClickDown(); }
public interface ICanClickUp : IClickable { void OnClickUp(); }
public interface ICanClickHold : IClickable { void OnClickHeld(); }

public static class ClickUtil
{
    static float RayLength { get; } = 1337.0f;

    static RaycastHit hit;

    static Collider previousCollider;
    static IClickable cachedClickable;

    static Camera camera;
    public static Camera Camera 
    {
        get
        {
            if (camera == null)
                camera = Camera.main;
            return camera;
        }
    }

    public static Vector3 MouseScreenPosition
        => Input.mousePosition;

    public static Vector3 MouseWorldPosition
        => Camera.ScreenToWorldPoint(MouseScreenPosition);

    public static Ray Ray 
    { get; private set; }

    public static Ray MouseRay
        => Camera.ScreenPointToRay(MouseScreenPosition);

    public static Vector3? GetNullableMouseWorldPosition(int layerMask = ~0)
    {
        Ray = MouseRay;
        if (Physics.Raycast(Ray, out hit, RayLength, layerMask))
            return hit.point;
        return null;
    }

    public static Vector3 GetMouseWorldPosition(int layerMask = ~0)
    {
        Vector3? point = GetNullableMouseWorldPosition(layerMask);
        return point != null ? point.Value : Ray.GetPoint(RayLength); 
    }

    public static Vector2 MouseViewPosition
        => Camera.ScreenToViewportPoint(MouseScreenPosition);

    public static RaycastHit Hit => hit;

    public static void OnClickDown()
        => (Clickable as ICanClickDown)?.OnClickDown();

    public static void OnClickHeld()
        => (Clickable as ICanClickHold)?.OnClickHeld();

    public static void OnClickUp()
        => (Clickable as ICanClickUp)?.OnClickUp();

    static Collider Collider
        => hit.collider;

    public static IClickable Clickable
    {
        get
        {
            if (Collider != previousCollider)
            {
                previousCollider = Collider;
                cachedClickable = previousCollider == null 
                    ? null 
                    : previousCollider.GetComponent<IClickable>();
            }
            return cachedClickable;
        }
    }

    public static Vector3 ScreenToWorldPoint(Vector3 screenPoint)
        => Camera.ScreenToWorldPoint(screenPoint);

    public static Vector2 WorldToScreenPoint(Vector3 worldPoint)
        => Camera.WorldToScreenPoint(worldPoint);
}
