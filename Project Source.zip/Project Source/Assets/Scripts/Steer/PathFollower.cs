using UnityEngine;

public class PathFollower : MonoBehaviour
{
    [SerializeField] TileOccupier tileOccupier = null;
    [SerializeField] Vehicle vehicle = null;
    [SerializeField] float pathRadius = 0.25f;
    [SerializeField] float predictDistance = 0.5f;
    [SerializeField] float littleFurtherDistance = 0.2f;

    public static bool Enabled { get => instance.enabled; set => instance.enabled = value; }
    public static bool IsFollowingPath
        => Enabled 
            && PathVisualizer.Count > 0
            && !PathVisualizer.HasReachedEnd;

    static PathFollower instance;

    Vector3 Position
    {
        get => transform.position;
        set
        {
            transform.position = value;
            if (Physics.Raycast(transform.position + 0.1f * Vector3.up, Vector3.down, out RaycastHit hit))
            {
                var tile = hit.collider.GetComponent<Tile>();
                if (tile != null)
                {
                    tileOccupier.OccupyTile(tile);
                }
            }
        }
    }

    public static void OnPathFound()
    {
        var path = PathUtil.Path;
        if (path.Count > 1)
            instance.vehicle.Seek(path[1]);
    }

    private void Awake()
    {
        if (instance != null)
        {
            Destroy(instance.gameObject);
        }
        instance = this;

        vehicle.Init(() => Position, p => Position = p, () => transform.rotation, r => transform.rotation = r);
    }

    private void Update()
    {
        if (IsFollowingPath)
        {
            FollowPath();
            PathVisualizer.SeekerPosition = Position;

            if ((Position - PathVisualizer.NextSeekerPosition).IsShorterThan(pathRadius * 1.5f))
                PathVisualizer.Dequeue();
        }
    }

    void FollowPath()
    {
        //Position = Vector3.MoveTowards(Position, PathVisualizer.NextSeekerPosition, Time.deltaTime * 6.9f);
        var path = PathUtil.Path;

        // predict future location
        Vector3 predict = vehicle.Velocity;
        predict = predict.normalized;
        predict *= predictDistance;
        Vector3 predictLocation = Position + predict;
        
        float worldRecord = float.MaxValue;
        
        Vector3 target = Vector3.zero;
        int count = path.Count;
        for (int i = 0; i < count - 2; i++)
        {
            Vector3 a = path[i];
            Vector3 b = path[i + 1];
            Vector3 normalPoint = predictLocation.GetNormalPoint(a, b);
            
            if (   normalPoint.x < Mathf.Min(a.x, b.x) - 0.1f 
                || normalPoint.x > Mathf.Max(a.x, b.x) + 0.1f
                || normalPoint.z < Mathf.Min(a.z, b.z) - 0.1f
                || normalPoint.z > Mathf.Max(a.z, b.z) + 0.1f)
            {
                normalPoint = b;
            }
        
            float distance = Vector3.Distance(predictLocation, normalPoint);
        
            if (distance < worldRecord)
            {
                worldRecord = distance;

                if (worldRecord > pathRadius)
                {
                    Vector3 direction = (b - a).normalized;
                    direction *= littleFurtherDistance;
                    target = normalPoint + direction;
                }
            }
        }

        if (worldRecord > pathRadius)
            vehicle.Seek(target);

        vehicle.Update();
    }
}
