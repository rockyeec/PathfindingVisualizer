using UnityEngine;
using System;

[Serializable]
public class Vehicle
{ 
    public Vector3 Position { get => GetPosition(); set => SetPosition(value); }
    public Vector3 Velocity { get; private set; }
    public Vector3 Acceleration { get; private set; }
    public Quaternion Rotation { get => GetRotation(); set => SetRotation(value); }
    
    [SerializeField] float maxForce = 1.0f;
    [SerializeField] float maxSpeed = 1.0f;    

    Func<Vector3> GetPosition { get; set; }
    Action<Vector3> SetPosition { get; set; }
    Func<Quaternion> GetRotation { get; set; }
    Action<Quaternion> SetRotation { get; set; }

    public void Init(Func<Vector3> getPosition, Action<Vector3> setPosition, Func<Quaternion> getRotation, Action<Quaternion> setRotation)
    {
        GetPosition = getPosition;
        SetPosition = setPosition;
        GetRotation = getRotation;
        SetRotation = setRotation;
    }
    public void Init(Transform transform)
    {
        Init(() => transform.position, p => transform.position = p, () => transform.rotation, r => transform.rotation = r);
    }

    public void Update()
    {
        Velocity += Acceleration;
        Velocity = Vector3.ClampMagnitude(Velocity, maxSpeed);
        Position += Velocity;
        Acceleration *= 0.0f;
        Rotation = Quaternion.LookRotation(Velocity);
    }

    public void ApplyForce(Vector3 force)
        => Acceleration += force;

    public void Seek(Vector3 target)
    {
        Vector3 desired = target - Position;
        desired = desired.normalized;
        desired *= maxSpeed;
        Vector3 steer = desired - Velocity;
        steer = Vector3.ClampMagnitude(steer, maxForce);
        ApplyForce(steer);
    }
}

