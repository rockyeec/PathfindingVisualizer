using System;
using System.Collections.Generic;
using UnityEngine;

public class UnidirectionPathfinder : IPathfinder
{
    public List<Vector3> Path { get; } = new List<Vector3>();
    public float PathLength { get; private set; }
    public int Iterations { get; private set; }
    public Vector2Int Start { get; private set; }
    public Vector2Int Goal { get; private set; }
    Vector2Int CurrentLocation { get; set; }

    Func<Heuristic> Heuristic { get; }
    Action OnFinish { get; }

    public delegate bool HasFoundGoalDelegate(Vector2Int currentLocation);
    HasFoundGoalDelegate HasFoundGoal { get; }

    public Dictionary<Vector2Int, float> CostSoFar { get; } = new Dictionary<Vector2Int, float>();
    Dictionary<Vector2Int, Vector2Int> Camefrom { get; } = new Dictionary<Vector2Int, Vector2Int>();
    BinaryHeap<Vector2Int> Frontier { get; } = new BinaryHeap<Vector2Int>(64 * 36);
    List<Vector2Int> RawPath { get; } = new List<Vector2Int>();

    bool IsReverse { get; }
    bool hasPath = true;

    public UnidirectionPathfinder(Func<Heuristic> heuristic, Action onFinish, HasFoundGoalDelegate hasFoundGoal = null, bool isReverse = false)
    {
        Heuristic = heuristic;
        OnFinish = onFinish;

        if (hasFoundGoal != null)
        {
            HasFoundGoal = hasFoundGoal;
        }
        else
        {
            HasFoundGoal = currentLocation => currentLocation == Goal;
        }

        IsReverse = isReverse;
    }

    public void Clear()
    {
        Frontier?.Clear();
        Path.Clear();
        RawPath.Clear();
        Camefrom.Clear();
        CostSoFar.Clear();
        Iterations = 0;
    }

    public void StartFindPath(Vector2Int start, Vector2Int goal)
    {
        Start = start;
        Goal = goal;
        Frontier.Add(start, 0.0f);
        Camefrom[start] = start;
        CostSoFar[start] = 0.0f;
        hasPath = true;
    }

    public void IterateFindPath()
    {
        if (Frontier.Count == 0)
        {
            hasPath = false;
            Finish();
            return;
        }

        CurrentLocation = Frontier.RemoveFirst();
        SetState(CurrentLocation, NodeState.Close);

        if (HasFoundGoal(CurrentLocation))
        {
            Finish();
            return;
        }

        var node = TileGrid.AllTiles[CurrentLocation];
        var neighbours = node.GetWalkableNeighbours();
        foreach (var nNode in neighbours)
        {
            var nextLocation = nNode.Key;

            float nudge = 0.0f;
            var x1 = CurrentLocation.x; var y1 = CurrentLocation.y;
            var x2 = nextLocation.x; var y2 = nextLocation.y;
            if ((x1 + y1) % 2 == 0 && x2 != x1) nudge = 1;
            if ((x1 + y1) % 2 == 1 && y2 != y1) nudge = 1;

            float newCost = CostSoFar[CurrentLocation] + CurrentLocation.GetDistanceTo(nextLocation) + node.Weight + (0.001f * nudge);

            if (!CostSoFar.ContainsKey(nextLocation)
                || newCost < CostSoFar[nextLocation])
            {
                CostSoFar[nextLocation] = newCost;
                float priority = newCost + Heuristic().Get(nextLocation, Goal);
                Frontier.Add(nextLocation, priority);
                Camefrom[nextLocation] = CurrentLocation;
                SetState(nextLocation, NodeState.Open);
            }
        }
        ++Iterations;
    }

    void SetState(Vector2Int location, NodeState state)
    {
        var node = TileGrid.AllTiles[location];
        if (node.State == NodeState.Start
            || node.State == NodeState.Target)
            return;
        node.State = state;
    }

    void Finish()
    {
        PathLength = 0.0f;
        if (hasPath && Camefrom.ContainsKey(CurrentLocation))
        {
            Vector2Int cameFromLocation = CurrentLocation;
            while (cameFromLocation != Start)
            {
                PathLength += cameFromLocation.GetDistanceTo(Camefrom[cameFromLocation]);
                RawPath.Add(cameFromLocation);
                cameFromLocation = Camefrom[cameFromLocation];
            }
            RawPath.Add(Start);
            if (!IsReverse)
                RawPath.Reverse();
            SimplifyPath();
        }
        OnFinish();
    }

    void SimplifyPath()
    {
        if (RawPath.Count == 0)
            return;

        Vector2Int oldDirection = Vector2Int.zero;
        int count = RawPath.Count - 1;
        for (int i = 0; i < count; i++)
        {
            Vector2Int newDirection = RawPath[i + 1] - RawPath[i];
            if (newDirection != oldDirection)
            {
                Path.Add(TileGrid.AllTiles[RawPath[i]].Tile.transform.position);
            }
            oldDirection = newDirection;
        }
        if (count - 1 >= 0)
            Path.Add(TileGrid.AllTiles[RawPath[count - 1]].Tile.transform.position);
        Path.Add(TileGrid.AllTiles[RawPath[count]].Tile.transform.position);
    }
}
