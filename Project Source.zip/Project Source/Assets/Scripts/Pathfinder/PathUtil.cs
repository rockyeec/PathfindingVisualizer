using System.Collections.Generic;
using UnityEngine;

public static class PathUtil
{
    public static bool IsFinish { get; private set; } = true;
    public static Heuristic Heuristic { get; set; }
    public static List<Vector3> Path => pathfinder.Path;
    public static bool IsBidirectional
    {
        get => pathfinder == bidirectionalPathfinder;
        set
        {
            if (value)
                pathfinder = bidirectionalPathfinder;
            else
                pathfinder = unidirectionPathfinder;
        }
    }

    public delegate void PathfindInfo(float length, float time, float iterations);
    public static event PathfindInfo OnComplete = delegate { };

    static readonly UnidirectionPathfinder unidirectionPathfinder = new UnidirectionPathfinder(() => Heuristic, Finish);
    static readonly BidirectionPathfinder bidirectionalPathfinder = new BidirectionPathfinder(() => Heuristic, Finish);
    static IPathfinder pathfinder = unidirectionPathfinder;

    static float time = 0.0f;

    public static void Clear()
    {
        foreach (var item in TileGrid.AllTiles)
        {
            item.Value.ResetOpenClose();
        }
        IsFinish = true;
        time = Time.time;
        pathfinder.Clear();
    }
    public static void StartFindPath(DraggableAgent start, DraggableAgent goal)
        => StartFindPath(start.OccupiedTile, goal.OccupiedTile);

    public static void StartFindPath(Tile start, Tile goal)
        => StartFindPath(start.Node, goal.Node);

    public static void StartFindPath(Node start, Node goal)
        => StartFindPath(start.Key, goal.Key);

    public static void StartFindPath(Vector2Int start, Vector2Int goal)
    {
        Clear();
        IsFinish = false;
        pathfinder.StartFindPath(start, goal);
    }

    public static void IterateFindPath()
    {
        if (IsFinish)
            return;

        pathfinder.IterateFindPath();
    }

    static void Finish()
    {
        IsFinish = true;

        time = Time.time - time;
        OnComplete(pathfinder.PathLength, time, pathfinder.Iterations);
    }
}