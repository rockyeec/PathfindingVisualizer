using System.Collections.Generic;
using UnityEngine;

public interface IPathfinder
{
    List<Vector3> Path { get; }
    float PathLength { get; }
    int Iterations { get; }
    Vector2Int Start { get; }
    Vector2Int Goal { get; }

    void Clear();
    void StartFindPath(Vector2Int start, Vector2Int goal);
    void IterateFindPath();
}
