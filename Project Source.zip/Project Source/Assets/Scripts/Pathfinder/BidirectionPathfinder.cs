using System.Collections.Generic;
using UnityEngine;
using System;

public class BidirectionPathfinder : IPathfinder
{
    public List<Vector3> Path { get; } = new List<Vector3>();
    public float PathLength => pathfinders[0].PathLength + pathfinders[1].PathLength;
    public int Iterations => pathfinders[0].Iterations + pathfinders[1].Iterations;
    public Vector2Int Start => pathfinders[0].Start;
    public Vector2Int Goal => pathfinders[0].Goal;
    Vector2Int? Intersection { get; set; }

    Action OnFinish { get; }

    readonly UnidirectionPathfinder[] pathfinders = new UnidirectionPathfinder[2];
    readonly bool[] isFinish = new bool[2];

    public BidirectionPathfinder(Func<Heuristic> heuristic, Action onFinish)
    {
        OnFinish = onFinish;
        pathfinders[0] = new UnidirectionPathfinder(heuristic, () => { isFinish[0] = true; Finish(); }, currentLocation => HasFoundGoal(currentLocation, 0, 1));
        pathfinders[1] = new UnidirectionPathfinder(heuristic, () => { isFinish[1] = true; Finish(); }, currentLocation => HasFoundGoal(currentLocation, 1, 0), true);

        bool HasFoundGoal(Vector2Int currentLocation, int fromIndex, int toIndex)
        {
            if (Intersection != null)
            {
                if (Intersection.Value == currentLocation)
                {
                    return true;
                }
            }
            else if (pathfinders[toIndex].CostSoFar.ContainsKey(currentLocation)
                || currentLocation == pathfinders[fromIndex].Goal)
            {
                Intersection = currentLocation;
                return true;
            }
            return false;
        }
    }

    public void Clear()
    {
        Path.Clear();
        Intersection = null;
        for (int i = 0; i < 2; i++)
        {
            pathfinders[i].Clear();
            isFinish[i] = false;
        }
    }

    public void StartFindPath(Vector2Int start, Vector2Int goal)
    {
        pathfinders[0].StartFindPath(start, goal);
        pathfinders[1].StartFindPath(goal, start);
    }

    public void IterateFindPath()
    {
        for (int i = 0; i < 2; i++)
            if (!isFinish[i])
                pathfinders[i].IterateFindPath();
    }

    void Finish()
    {
        foreach (var item in isFinish)
        {
            if (!item)
                return;
        }

        if (pathfinders[1].Path.Count != 0)
            pathfinders[1].Path.RemoveAt(0);

        Path.AddRange(pathfinders[0].Path);
        Path.AddRange(pathfinders[1].Path);

        OnFinish();
    }
}