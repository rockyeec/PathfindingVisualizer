using UnityEngine;
using System;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Clicker : MonoBehaviour
{
    [SerializeField] Canvas canvas = null;
    [SerializeField] Image noClickImage = null;

    public static event Action OnClickUpGlobal = delegate { };
    public static event Action OnClickDownGlobal = delegate { };

    bool IsOverIClickable => ClickUtil.GetNullableMouseWorldPosition() != null;
    bool CanClick => !EventSystem.current.IsPointerOverGameObject();

    Vector3 prevMousePos;

    private void Update()
    {
        if (!PathUtil.IsFinish)
        {
            NoClick();
            return;
        }

        if (PathFollower.IsFollowingPath)
        {
            NoClick();
            return;
        }

        if (!Cursor.visible)
        {
            noClickImage.gameObject.SetActive(false);
            Cursor.visible = true;
        }

        if (Input.GetMouseButtonDown(0))
        {
            OnClickDownGlobal();
            if (CanClick)
            {
                if (IsOverIClickable)
                {
                    ClickUtil.OnClickDown();
                    ClickUtil.OnClickHeld();
                }
            }
        }
        else if (Input.GetMouseButton(0))
        {
            if (CanClick)
            {
                Vector3 mousePosition = ClickUtil.MouseScreenPosition;
                bool isMouseMove = (prevMousePos - mousePosition).IsLongerThan(1e-2f);
                prevMousePos = mousePosition;
                if (isMouseMove)
                    if (IsOverIClickable)
                        ClickUtil.OnClickHeld();
            }
        }

        if (Input.GetMouseButtonUp(0))
        {
            if (CanClick)
            {
                OnClickUpGlobal();
                if (IsOverIClickable)
                {
                    ClickUtil.OnClickUp();
                }
            }
        }
    }

    void NoClick()
    {
        bool canClick = CanClick;
        
        noClickImage.gameObject.SetActive(canClick);
        Cursor.visible = !canClick;

        if (!canClick)
            return;
        
        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas.transform as RectTransform, Input.mousePosition, canvas.worldCamera, out Vector2 pos);
        noClickImage.transform.position = canvas.transform.TransformPoint(pos);
    }
}
