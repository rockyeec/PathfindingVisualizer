using System.Collections.Generic;

public class BinaryHeap<T> where T : struct
{
	class Element
    {
		public T Data { get; set; }
		public float Cost { get; set; }
    }
	List<Element> Elements { get; }

	public BinaryHeap(int size)
    {
		Elements = new List<Element>(size);
    }

	public int Count { get; private set; } = 0;

	public void Clear() => Count = 0;

	public void Add(T item, float cost)
	{
		if (Count >= Elements.Count)
			Elements.Add(new Element() { Data = item, Cost = cost });
		else
			Elements[Count] = new Element() { Data = item, Cost = cost };

		SortUp();
		++Count;
	}

	public T RemoveFirst()
	{
		Element firstItem = Elements[0];

		--Count;
		Elements[0] = Elements[Count];

		SortDown();
		return firstItem.Data;
	}

	void SortDown()
	{
		int thisIndex = 0;
		while (true)
		{
			int childIndexLeft = GetLeftChildIndex(thisIndex);
			bool hasLeftChild = childIndexLeft < Count;
			if (hasLeftChild)
			{
				int swapIndex = childIndexLeft;

				int childIndexRight = GetRightChildIndex(thisIndex);
				bool hasRightChild = childIndexRight < Count;
				if (hasRightChild)
				{
					if (Elements[childIndexLeft].Cost > Elements[childIndexRight].Cost)
					{
						swapIndex = childIndexRight;
					}
				}

				if (Elements[thisIndex].Cost > Elements[swapIndex].Cost)
				{
					Swap(thisIndex, swapIndex);
					thisIndex = swapIndex;
				}
				else
				{
					return;
				}
			}
			else
			{
				return;
			}
		}
	}

	void SortUp()
	{
		int thisIndex = Count;
		while (true)
		{
			int parentIndex = GetParentIndex(thisIndex);
			if (Elements[parentIndex].Cost > Elements[thisIndex].Cost)
			{
				Swap(thisIndex, parentIndex);
				thisIndex = parentIndex;
			}
			else
			{
				break;
			}
		}
	}

	int GetParentIndex(int index) => (index - 1) / 2;
	int GetLeftChildIndex(int index) => 2 * index + 1;
	int GetRightChildIndex(int index) => 2 * index + 2;

	void Swap(int index1, int index2)
	{
		Element tempItem = Elements[index1];
		Elements[index1] = Elements[index2];
		Elements[index2] = tempItem;
	}
}