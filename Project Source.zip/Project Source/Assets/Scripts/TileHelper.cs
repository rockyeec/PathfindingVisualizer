using System;

public class TileHelper
{
    public Action<bool> FadeGrow { get; }
    public Action Tick { get; }
    public Action Init { get; }
    public TileHelper(Action<bool> fadeGrow, Action tick, Action init)
    {
        FadeGrow = fadeGrow;
        Tick = tick;
        Init = init;
    }
}
