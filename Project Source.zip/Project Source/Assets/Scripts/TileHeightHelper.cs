using UnityEngine;
using System;
using System.Collections.Generic;

public class TileHeightHelper
{
    Material Material { get; }
    BoxCollider BoxCollider { get; }
    Lerper<float> Lerper { get; }

    float VisualHeight
    {
        get => Material.GetFloat(UniformIDs.Height);
        set => Material.SetFloat(UniformIDs.Height, value);
    }

    float Height
    {
        get => VisualHeight;
        set
        {
            VisualHeight = value;
            BoxCollider.size = BoxCollider.size.With(y: value);
            BoxCollider.center = BoxCollider.center.With(y: value * 0.5f);
        }
    }

    public TileHeightHelper(float animationDuration, Material material, BoxCollider boxCollider, Func<float> getMinimumHeight, Func<float> getMaximumHeight, List<TileHelper> tileHelpers)
    {
        Material = material;
        BoxCollider = boxCollider;


        Lerper = new Lerper<float>(
            () => Height,
            (a, b, t) =>
            {
                Height = Mathf.LerpUnclamped(a, b, t.SmootherStep());
            })
        { Duration = animationDuration };

        Height = getMinimumHeight();

        void FadeGrow(bool isGrow) => Lerper.Begin(isGrow ? getMaximumHeight() : getMinimumHeight());
        void Tick() => Lerper.TryUpdate();
        void Init() => Height = getMinimumHeight();
        tileHelpers.Add(new TileHelper(FadeGrow, Tick, Init));
    }
}
