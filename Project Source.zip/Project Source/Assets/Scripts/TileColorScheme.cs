using UnityEngine;

[CreateAssetMenu(fileName = "New Tile Color Scheme",menuName = "Scriptable Objects/Tile Color Scheme")]
public class TileColorScheme : ScriptableObject
{
    public Color EmptyColor => emptyColor;
    public Color UpColor => upColor;
    public Color OpenColor => openColor;
    public Color CloseColor => closeColor;
    public Color StartColor => startColor;
    public Color TargetColor => targetColor;

    [SerializeField] Color emptyColor = Color.white;
    [SerializeField] Color upColor = Color.gray;
    [SerializeField] Color openColor = Color.green;
    [SerializeField] Color closeColor = Color.cyan;
    [SerializeField] Color startColor = Color.magenta;
    [SerializeField] Color targetColor = Color.red;
}
