using System.Collections.Generic;
using UnityEngine;
using System;

public static class NodeNeighbourUtil
{
    enum KernelKey
    {
        TopLeft,    Top,    TopRight,
        Left,               Right,
        BottomLeft, Bottom, BottomRight
    }
    private static Dictionary<KernelKey, Vector2Int> KernelWithDiagonal { get; } = new Dictionary<KernelKey, Vector2Int>
    {
        { KernelKey.TopLeft, new Vector2Int(-1, 1) },   { KernelKey.Top, Vector2Int.up },        { KernelKey.TopRight, Vector2Int.one },
        { KernelKey.Left, Vector2Int.left },                                                     { KernelKey.Right, Vector2Int.right },
        { KernelKey.BottomLeft, -Vector2Int.one },      { KernelKey.Bottom, Vector2Int.down },   { KernelKey.BottomRight, new Vector2Int(1, -1) }
    };
    private static Vector2Int[] KernelWithoutDiagonal { get; } = new Vector2Int[]
    {
                         Vector2Int.up,        
        Vector2Int.left,                Vector2Int.right,
                         Vector2Int.down
    };
    private static List<Node> Neighbours { get; } = new List<Node>();

    static Func<Vector2Int, KernelKey, KernelKey, bool> DiagonalCheck { get; set; } = IsBothWalkable;
    static Action<Node> GetNeighbourAction { get; set; } = AllowDiagonalGet;

    public static bool IsCrossCorners 
    {
        get => DiagonalCheck == IsEitherWalkable;
        set
        {
            if (value)
                DiagonalCheck = IsEitherWalkable;
            else
                DiagonalCheck = IsBothWalkable;
        }
    }

    public static bool IsAllowDiagonal
    {
        get => GetNeighbourAction == AllowDiagonalGet;
        set
        {
            if (value)
                GetNeighbourAction = AllowDiagonalGet;
            else
                GetNeighbourAction = NoDiagonalGet;
        }
    }

    public static List<Node> GetWalkableNeighbours(this Node current)
    {
        Neighbours.Clear();
        GetNeighbourAction(current);
        return Neighbours;
    }

    static void NoDiagonalGet(Node current)
    {
        var nodes = TileGrid.AllTiles;
        var currentKey = current.Key;
        foreach (var delta in KernelWithoutDiagonal)
            if (nodes.TryGetValue(currentKey + delta, out Node neighbourNode))
                if (neighbourNode.IsWalkable)
                    Neighbours.Add(neighbourNode);
    }

    static void AllowDiagonalGet(Node current)
    {
        var nodes = TileGrid.AllTiles;
        var currentKey = current.Key;

        foreach (var delta in KernelWithDiagonal)
        {
            if (nodes.TryGetValue(currentKey + delta.Value, out Node neighbourNode))
            {
                if (!neighbourNode.IsWalkable)
                    continue;

                switch (delta.Key)
                {
                    case KernelKey.TopLeft:
                        if (!DiagonalCheck(currentKey, KernelKey.Top, KernelKey.Left)) continue;
                        break;
                    case KernelKey.TopRight:
                        if (!DiagonalCheck(currentKey, KernelKey.Top, KernelKey.Right)) continue;
                        break;
                    case KernelKey.BottomLeft:
                        if (!DiagonalCheck(currentKey, KernelKey.Bottom, KernelKey.Left)) continue;
                        break;
                    case KernelKey.BottomRight:
                        if (!DiagonalCheck(currentKey, KernelKey.Bottom, KernelKey.Right)) continue;
                        break;
                    default:
                        break;
                }

                Neighbours.Add(neighbourNode);
            }
        }
    }

    static bool IsEitherWalkable(Vector2Int currentKey, KernelKey a, KernelKey b)
    {
        var nodes = TileGrid.AllTiles;
        if (nodes.TryGetValue(currentKey + KernelWithDiagonal[a], out Node resultNode))
        {
            if (resultNode.IsWalkable)
                return true;
        }
        if (nodes.TryGetValue(currentKey + KernelWithDiagonal[b], out resultNode))
        {
            if (resultNode.IsWalkable)
                return true;
        }
        return false;
    }

    static bool IsBothWalkable(Vector2Int currentKey, KernelKey a, KernelKey b)
    {
        var nodes = TileGrid.AllTiles;
        if (nodes.TryGetValue(currentKey + KernelWithDiagonal[a], out Node resultNode))
        {
            if (!resultNode.IsWalkable)
                return false;
        }
        if (nodes.TryGetValue(currentKey + KernelWithDiagonal[b], out resultNode))
        {
            if (!resultNode.IsWalkable)
                return false;
        }
        return true;
    }

    public static float GetDistanceTo(this Vector2Int a, Vector2Int b)
    {
        int dstX = Mathf.Abs(a.x - b.x);
        int dstY = Mathf.Abs(a.y - b.y);
        if (dstX > dstY)
            return 1.4f * dstY + (dstX - dstY);
        return 1.4f * dstX + (dstY - dstX);
    }
}