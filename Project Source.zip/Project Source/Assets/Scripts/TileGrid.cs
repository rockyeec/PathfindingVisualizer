using System.Collections.Generic;
using UnityEngine;

public class TileGrid : MonoBehaviour
{
    [SerializeField] Vector2Int columnsAndRows = Vector2Int.one * 69;
    public static Dictionary<Vector2Int, Node> AllTiles { get; } = new Dictionary<Vector2Int, Node>();
    public static DraggableAgent Seeker { get; private set; }
    public static DraggableAgent Target { get; private set; }

    int tileID;

    private void Awake()
    {
        tileID = ObjectPool.StringToHash("Tile");

        Spawn();
    }

    public void Spawn()
    {
        ClearAll();

        Vector2 start = -(Vector2)(columnsAndRows - Vector2Int.one) * 0.5f;

        for (int y = 0; y < columnsAndRows.y; y++)
        {
            for (int x = 0; x < columnsAndRows.x; x++)
            {
                Vector3 position = ( start + new Vector2(x, y) ).AsVector3WithYZswap();
                var tile = ObjectPool.PoolOut(tileID, position, Quaternion.identity) as Tile;

                Vector2Int key = new Vector2Int(x, y);
                tile.Node.Key = key;
                AllTiles.Add(key, tile.Node);
            }
        }

        Tile[] randomTiles = new Tile[2];
        randomTiles[0] = AllTiles[columnsAndRows / 2 - Vector2Int.right * 6].Tile;
        randomTiles[1] = AllTiles[columnsAndRows / 2 + Vector2Int.right * 6].Tile;
        //randomTiles[0] = AllTiles.GetRandomValue().Tile;
        //do
        //{
        //    randomTiles[1] = AllTiles.GetRandomValue().Tile;
        //} while (randomTiles[0] == randomTiles[1]);

        Seeker = ObjectPool.PoolOut(ObjectPool.StringToHash("Seeker"), randomTiles[0].transform.position, Quaternion.identity) as DraggableAgent;
        Target = ObjectPool.PoolOut(ObjectPool.StringToHash("Target"), randomTiles[1].transform.position, Quaternion.identity) as DraggableAgent;
    }

    void ClearAll()
    {
        foreach (var item in AllTiles)
        {
            ObjectPool.PoolIn(item.Value.Tile);
        }
        AllTiles.Clear();

        if (Seeker != null)
            ObjectPool.PoolIn(Seeker);
        if (Target != null)
            ObjectPool.PoolIn(Target);
    }
}
