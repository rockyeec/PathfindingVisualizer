using System;
using System.Linq;
using System.Reflection;

public static class SubclassUtil
{
    public static Type[] GetAllSubclasses<T>() where T : class
        => Assembly.GetAssembly(typeof(T)).GetTypes().Where(myType => !myType.IsAbstract && myType.IsSubclassOf(typeof(T))).ToArray();
}
