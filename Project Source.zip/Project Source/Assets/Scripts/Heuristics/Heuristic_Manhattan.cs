using UnityEngine;

public class Heuristic_Manhattan : Heuristic
{
    public override string DisplayName { get; } = "A* Manhattan";            
    public override float Get(Vector2Int a, Vector2Int b) => Mathf.Abs(a.x - b.x) + Mathf.Abs(a.y - b.y);
}
