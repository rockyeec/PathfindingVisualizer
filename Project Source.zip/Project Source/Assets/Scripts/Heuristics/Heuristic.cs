using UnityEngine;

public abstract class Heuristic
{
    public abstract string DisplayName { get; }
    public abstract float Get(Vector2Int a, Vector2Int b);
}
