using UnityEngine;

public class Heuristic_Octile : Heuristic
{
    public override string DisplayName { get; } = "A* Octile";
    public override float Get(Vector2Int a, Vector2Int b)
    {
        float x = Mathf.Abs(a.x - b.x);
        float y = Mathf.Abs(a.y - b.y);

        return Mathf.Max(x, y) + (0.4f) * Mathf.Min(x, y);
    }
}
