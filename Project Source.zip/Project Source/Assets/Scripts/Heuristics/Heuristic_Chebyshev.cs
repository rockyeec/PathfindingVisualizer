using UnityEngine;

public class Heuristic_Chebyshev : Heuristic
{
    public override string DisplayName { get; } = "A* Chebyshev";
    public override float Get(Vector2Int a, Vector2Int b) => Mathf.Max(Mathf.Abs(a.x - b.x), Mathf.Abs(a.y - b.y));
}
