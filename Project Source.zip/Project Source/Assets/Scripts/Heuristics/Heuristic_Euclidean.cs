using UnityEngine;

public class Heuristic_Euclidean : Heuristic
{
    public override string DisplayName { get; } = "A* Euclidean";
    public override float Get(Vector2Int a, Vector2Int b) => Vector2Int.Distance(a, b);
}
