using UnityEngine;

public class Heuristic__Dijkstra : Heuristic
{
    public override string DisplayName { get; } = "Dijkstra";
    public override float Get(Vector2Int a, Vector2Int b) => 0.0f;
}
