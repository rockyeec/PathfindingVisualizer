﻿using System.Collections.Generic;
using UnityEngine;

public abstract class Poolable : MonoBehaviour
{
    public int Hash 
    { 
        get => hash;
        set // only can set once
        {
            if (isInstantiate)
            {
                isInstantiate = false;
                hash = value;
            }
        }
    }
    public virtual void Init() { }
    public virtual void DeInit() { }

    bool isInstantiate = true;
    int hash;
}

public class ObjectPool : MonoBehaviour
{
    readonly static Dictionary<int, Stack<Poolable>> pooledObjects = new Dictionary<int, Stack<Poolable>>();

    [SerializeField] string[] objectsToLoadThisScene = null;

    public static int StringToHash(in string s)
    {
        int i = s.GetHashCode();
        if (pooledObjects.ContainsKey(i)) 
            return i;

        var gO = Resources.Load("Pooled Prefabs/" + s) as GameObject;
        var poolable = gO.GetComponent<Poolable>();
        poolable.Hash = i;

        Stack<Poolable> q = new Stack<Poolable>();
        q.Push(poolable);

        pooledObjects.Add(i, q);

        return i;
    }

    public static Poolable Peek(int id) => pooledObjects[id].Peek();

    public static Poolable PoolOut(in int key)
    {
        var poolable = GetObject(key);
        if (poolable != null)
            poolable.Init();
        return poolable;
    }

    public static Poolable PoolOut(in int key, Vector3 position, Quaternion rotation)
    {
        Poolable poolable = GetObject(key);
        if (poolable != null)
        {
            poolable.transform.SetPositionAndRotation(position, rotation);
            poolable.Init();
        }
        return poolable;
    }

    public static Poolable PoolOut(in int key, Transform parent)
    {
        Poolable poolable = GetObject(key);
        if (poolable != null)
        {
            Transform poolableTransform = poolable.transform;
            poolableTransform.SetParent(parent);
            poolableTransform.localPosition = Vector3.zero;
            poolableTransform.localRotation = Quaternion.identity;
            poolable.Init();
        }
        return poolable;
    }

    public static void PoolIn(Poolable poolable)
    {
        poolable.DeInit();
        int key = poolable.Hash;
        if (!pooledObjects.ContainsKey(key))
        {
            Destroy(poolable.gameObject);
            return;
        }
        poolable.gameObject.SetActive(false);
        pooledObjects[key].Push(poolable);
    }

    private static Poolable GetObject(in int key)
    {        
        Stack<Poolable> q = pooledObjects[key];
        Poolable poolable;
        if (q.Count == 1)
        {
            poolable = Instantiate(q.Peek());
            poolable.Hash = key;
        }
        else
        {
            poolable = q.Pop();
            poolable.gameObject.SetActive(true);
        }           
        return poolable;
    }

    private void Awake()
    {
        foreach (var item in pooledObjects)
        {
            int length = item.Value.Count - 1;
            for (int i = 0; i < length; i++)
            {
                item.Value.Pop();
            }
        }

        foreach (var item in objectsToLoadThisScene)
        {
            int id = StringToHash(item);
        }
    }
}
