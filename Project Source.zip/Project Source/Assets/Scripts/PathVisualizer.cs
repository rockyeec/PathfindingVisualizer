using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class PathVisualizer : MonoBehaviour
{
    [SerializeField] float aboveGroundHeight = 0.2f;

    static PathVisualizer instance;
    LineRenderer line;

    int nextIndex = 1;

    public static int Count => instance.line.positionCount;

    public static Vector3 SeekerPosition
    {
        get => instance.line.GetPosition(0).With(y: 0.0f);
        set
        {
            for (int i = 0; i < instance.nextIndex; i++)
            {
                instance.line.SetPosition(i, value.With(y: instance.aboveGroundHeight));
            }
        }
    }

    public static Vector3 NextSeekerPosition 
        => instance.line.GetPosition(instance.nextIndex).With(y: 0.0f);

    public static void Dequeue()
    {
        if (Count > 0 
            && instance.nextIndex < Count - 2)
        {
            ++instance.nextIndex;
        }
        else if (instance.nextIndex == Count - 2)
        {
            HasReachedEnd = true;
        }
    }

    public static bool HasReachedEnd { get; private set; }

    public static void Draw(List<Vector3> path)
    {
        var pathArr = path.ToArray();
        for (int i = 0; i < pathArr.Length; i++)
        {
            pathArr[i] = pathArr[i].With(y: instance.aboveGroundHeight);
        }
        instance.line.positionCount = pathArr.Length;
        instance.line.SetPositions(pathArr);

        instance.nextIndex = 1;
        HasReachedEnd = false;
    }

    public static void ResetLine() => instance.line.positionCount = 0;

    private void Awake()
    {
        if (instance != null)
            Destroy(instance.gameObject);
        instance = this;
        line = GetComponent<LineRenderer>();
    }
}
