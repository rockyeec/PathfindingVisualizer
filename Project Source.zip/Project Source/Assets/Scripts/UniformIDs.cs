using UnityEngine;

public static class UniformIDs
{
    public static int Height { get; } = Shader.PropertyToID("_Height");
    public static int Color { get; } = Shader.PropertyToID("_Color");
}
