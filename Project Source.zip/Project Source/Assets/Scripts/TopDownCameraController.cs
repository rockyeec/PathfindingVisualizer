using UnityEngine;

namespace rockUtil
{
    // How to use ? Just attach this to an empty Game Object, the Reset() Method takes care of everything on attach
    // ************************************************************************************************************
    // *    this.transform acts as both the Truck and Dolly (left right forward backward translation)             *
    // *    the Pedestal is a child of this.transform (up down translation)                                       *
    // *    the Tilt is a child of the Pedestal (up down rotation)                                                *
    // ************************************************************************************************************
    public class TopDownCameraController : MonoBehaviour
    {
        [Header("Values")]
        [SerializeField] float truckSpeed = 13.37f;
        [SerializeField] float minPitch = 10.0f;
        [SerializeField] float maxPitch = 50.0f;
        [SerializeField] float minHeight = 1.0f;
        [SerializeField] float maxHeight = 6.9f;
        [SerializeField] float scrollSmoothTime = 0.15f;
        [SerializeField] float scrollSensitivity = 0.25f;
        [SerializeField] float yawSensitivity = 6.9f;
        [SerializeField] Vector2 mapHalfDimension = Vector2.one * 69.0f;

        [Header("Ground Collision Check")]
        [SerializeField] LayerMask groundLayer = 1 << 6;
        [SerializeField] float rayLength = 6.9f;

        [Header("Camera Move Transforms")]
        [SerializeField] Transform pedestal = null;
        [SerializeField] Transform tilt = null;

        Camera Camera => ClickUtil.Camera;
        float ScrollPercent { get; set; } = 1.0f;

        float tiltVel, pedestalVel;
        float yVel;
        RaycastHit hit;
        float yaw;

        private void Reset()
        {
            name = "Top Down Camera Controller";
            transform.position = transform.position.With(y: 0.0f);
            AssignTransforms("Pedestal", ref pedestal, transform, Vector3.zero.With(y:maxHeight), Quaternion.identity);
            AssignTransforms("Tilt", ref tilt, pedestal, Vector3.zero, Quaternion.Euler(maxPitch, 0.0f, 0.0f));
        }
        void AssignTransforms(string transformName, ref Transform thisTransform, Transform parent, Vector3 localPosition, Quaternion localRotation)
        {
            if (thisTransform == null)
            {
                if (parent.childCount != 0)
                {
                    thisTransform = parent.GetChild(0);
                }
                else
                {
                    thisTransform = new GameObject().transform;
                    thisTransform.SetParent(parent);
                }
                thisTransform.name = transformName;
                thisTransform.localPosition = localPosition;
                thisTransform.localRotation = localRotation;
            }
        }

        private void Awake()
        {
            Camera.transform.SetParent(tilt);
            Camera.transform.localPosition = Vector3.zero;
            Camera.transform.localRotation = Quaternion.identity;

            transform.position = transform.position.With(y: 0.0f);
            pedestal.localPosition = Vector3.zero.With(y: maxHeight);
            tilt.localEulerAngles = Vector3.zero.With(x: maxPitch);
        }

        private void Update()
        {
            ScrollPercent -= Input.mouseScrollDelta.y * scrollSensitivity;

            float deltaTime = Time.deltaTime;
            HandleTruckAndDolley(in deltaTime);
            HandleTiltAndPedestal();
            HandeRotation();
        }
        
        void HandleTruckAndDolley(in float deltaTime)
        {
            Vector2 mouseViewportPoint = ClickUtil.MouseViewPosition - Vector2.one * 0.5f;

            float mouseEdgeHor = Mathf.Sign(mouseViewportPoint.x) * Mathf.InverseLerp(0.48f, 0.5f, (Mathf.Abs(mouseViewportPoint.x)));
            float mouseEdgeVer = Mathf.Sign(mouseViewportPoint.y) * Mathf.InverseLerp(0.48f, 0.5f, (Mathf.Abs(mouseViewportPoint.y)));

            float keyboardHor = (Input.GetKey(KeyCode.D) ? 1.0f : 0.0f) - (Input.GetKey(KeyCode.A) ? 1.0f : 0.0f);
            float keyboardVer = (Input.GetKey(KeyCode.W) ? 1.0f : 0.0f) - (Input.GetKey(KeyCode.S) ? 1.0f : 0.0f);

            float hor = Mathf.Abs(mouseEdgeHor) > Mathf.Abs(keyboardHor) ? mouseEdgeHor : keyboardHor;
            float ver = Mathf.Abs(mouseEdgeVer) > Mathf.Abs(keyboardVer) ? mouseEdgeVer : keyboardVer;

            transform.Translate(deltaTime * truckSpeed * new Vector3(hor, 0.0f, ver), Space.Self);

            float xCur = transform.position.x;
            float zCur = transform.position.z;
            float xNew = Mathf.Sign(xCur) * Mathf.Min(Mathf.Abs(xCur), mapHalfDimension.x);
            float zNew = Mathf.Sign(zCur) * Mathf.Min(Mathf.Abs(zCur), mapHalfDimension.y);
            transform.position = transform.position.With(x: xNew, z: zNew);

            if (Physics.Raycast(
                transform.position + 0.5f * rayLength * Vector3.up,
                Vector3.down,
                out hit, 
                rayLength,
                groundLayer))
            {
                float y = Mathf.SmoothDamp(transform.position.y, hit.point.y, ref yVel, 0.1f);
                transform.position = transform.position.With(y: y);
            }
        }
        void HandleTiltAndPedestal()
        {
            ScrollPercent = Mathf.Clamp01(ScrollPercent);
            float pedestalY = Mathf.LerpUnclamped(minHeight, maxHeight, ScrollPercent);
            float tiltX = Mathf.LerpUnclamped(minPitch, maxPitch, ScrollPercent);

            float smoothPedestalY = Mathf.SmoothDamp(pedestal.localPosition.y, pedestalY, ref pedestalVel, scrollSmoothTime);
            float smoothTiltX = Mathf.SmoothDampAngle(tilt.localEulerAngles.x, tiltX, ref tiltVel, scrollSmoothTime);

            pedestal.localPosition = Vector3.zero.With(y: smoothPedestalY);
            tilt.localEulerAngles = Vector3.zero.With(x: smoothTiltX);
        }
        void HandeRotation()
        {
            if (!Input.GetMouseButton(2))
                return;

            yaw += Input.GetAxis("Mouse X");
            transform.eulerAngles = yaw * yawSensitivity * Vector3.up;

            ScrollPercent -= Input.GetAxis("Mouse Y") * scrollSensitivity;
        }
    }
}