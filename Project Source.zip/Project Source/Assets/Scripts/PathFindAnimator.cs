using UnityEngine;

public class PathFindAnimator : MonoBehaviour
{
    static PathFindAnimator instance;

    [SerializeField] float animationInterval = 0.420f;
    float time;

    public void SetAnimationInterval(float value) => animationInterval = value;

    public static void FindPath(DraggableAgent start, DraggableAgent goal)
    {
        PathVisualizer.ResetLine();
        PathUtil.StartFindPath(start, goal);

        instance.StartTimer();
        instance.enabled = true;
    }

    public static void Pause() => instance.enabled = false;
    public static void Play() => instance.enabled = true;

    bool CanUpdate()
    {
        bool canUpdate = !(Time.time < time);
        if (canUpdate)
            StartTimer();
        return canUpdate;
    }
    void StartTimer()
        => time = Time.time + animationInterval;

    private void Awake()
    {
        if (instance != null)
            Destroy(instance.gameObject);
        instance = this;
        enabled = false;
    }

    void Update()
    {
        while (CanUpdate())
        {
            PathUtil.IterateFindPath();

            if (PathUtil.IsFinish)
            {
                enabled = false;

                PathVisualizer.Draw(PathUtil.Path);
                PathFollower.OnPathFound();

                break;
            }
        }        
    }
}
