using UnityEngine;
using System.Collections.Generic;

[RequireComponent(typeof(CapsuleCollider))]
[RequireComponent(typeof(TileOccupier))]
public class DraggableAgent : Poolable, ICanClickDown
{
    public static bool IsDrag { get; private set; }
    static readonly List<DraggableAgent> allDraggables = new List<DraggableAgent>();

    [SerializeField] TileOccupier tileOccupier = null;

    public Tile OccupiedTile => tileOccupier.OccupiedTile;

    CapsuleCollider capsule;
    Vector3 targetPosition, currentVelocity;

    public void OnClickDown()
    {
        targetPosition = transform.position;
        enabled = IsDrag = true;
        capsule.enabled = false;
    }

    private void Clicker_OnClickUpGlobal()
    {
        if (!enabled) return;

        enabled = IsDrag = false;
        capsule.enabled = true;
        transform.position = targetPosition;
        currentVelocity = Vector3.zero;
    }

    public static void SetGlobalDraggable(bool isDraggable)
    {
        foreach (var item in allDraggables)
        {
            item.capsule.enabled = isDraggable;
        }
    }

    public static void SetPreviousTileEmpty()
    {
        foreach (var item in allDraggables)
        {
            item.tileOccupier.SetPreviousTileStateEmpty();
        } 
    }

    private void Awake()
    {
        capsule = GetComponent<CapsuleCollider>();
        enabled = false;
        Clicker.OnClickUpGlobal += Clicker_OnClickUpGlobal;
    }

    private void OnDestroy()
    {
        Clicker.OnClickUpGlobal -= Clicker_OnClickUpGlobal; 
    }

    private void Update()
    {
        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref currentVelocity, 0.1f);

        var tile = ClickUtil.Clickable as Tile;
        if (tile == null)
            return;

        if (!tile.Node.IsWalkable)
            return;

        if (tile == OccupiedTile)
            return;

        tileOccupier.OccupyTile(tile);
        targetPosition = tile.transform.position;
    }

    public override void Init()
    {
        base.Init();
        allDraggables.Add(this);
        InitializePosition();
    }

    public override void DeInit()
    {
        base.DeInit();
        allDraggables.Remove(this);        
        tileOccupier.ClearOccupation();
    }

    void InitializePosition()
    {
        if (Physics.Raycast(transform.position + 0.1f * Vector3.up, Vector3.down, out RaycastHit hit))
        {
            var tile = hit.collider.GetComponent<Tile>();
            if (tile != null)
            {
                tileOccupier.OccupyTile(tile);
                targetPosition = tile.transform.position;
            }
        }
    }
}
